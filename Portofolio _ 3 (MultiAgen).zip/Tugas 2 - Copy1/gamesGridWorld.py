import pygame
import sys
import random
import numpy as np

# Ukuran grid
GRID_SIZE = 50

# Inisialisasi Pygame
pygame.init()

# Ukuran layar
SCREEN_WIDTH = 300
SCREEN_HEIGHT = 300

# Warna
GRAY = (192, 192, 192)
BLACK = (0, 0, 0)

# Inisialisasi layar
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Luffy Games")

# Memuat gambar pemain
player_image = pygame.image.load("luffy.png")
reward_image = pygame.image.load("hartakarun.png")
meriam_image1= pygame.image.load("meriamperang.png")
meriam_image2= pygame.image.load("meriamperang.png")
meriam_image3= pygame.image.load("meriamperang.png")
meriam_image4= pygame.image.load("meriamperang.png")
meriam_image5= pygame.image.load("meriamperang.png")
coin_image1 = pygame.image.load("coin.png")
coin_image2 = pygame.image.load("coin.png")
coin_image3 = pygame.image.load("coin.png")
coin_image4 = pygame.image.load("coin.png")
coin_image5 = pygame.image.load("coin.png")
coin_image6 = pygame.image.load("coin.png")

# Inisialisasi posisi awal Player
player_image = pygame.transform.scale(player_image, (35, 35))
player_rect = player_image.get_rect()
# player_rect.x = 0
# player_rect.y = 0

# Inisialisasi posisi awal Agen Kedua
agent2_image = pygame.image.load("zoro.png")  # Ganti 'agent2.png' dengan nama gambar agen kedua Anda
agent2_image = pygame.transform.scale(agent2_image, (35, 35))  # Sesuaikan ukuran gambar jika perlu
agent2_rect = agent2_image.get_rect()
# agent2_rect.x = (SCREEN_WIDTH // GRID_SIZE+ 1) * GRID_SIZE
# agent2_rect.y = (SCREEN_HEIGHT // GRID_SIZE+1) * GRID_SIZE


# Inisialisasi posisi awal harta
reward_image = pygame.transform.scale(reward_image, (50, 50))  # Sesuaikan ukuran hadiah jika diperlukan
reward_rect = reward_image.get_rect()
reward_rect.x = (SCREEN_WIDTH // GRID_SIZE - 1) * GRID_SIZE
reward_rect.y = (SCREEN_HEIGHT // GRID_SIZE - 1) * GRID_SIZE

# Inisialisasi posisi jebakan
meriam_image1 = pygame.transform.scale(meriam_image1, (40, 40))  # Sesuaikan ukuran hadiah jika diperlukan
meriam_rect1 = meriam_image1.get_rect()
meriam_rect1.x = (SCREEN_WIDTH // GRID_SIZE - 2) * GRID_SIZE
meriam_rect1.y = (SCREEN_HEIGHT // GRID_SIZE - 2) * GRID_SIZE

# Inisialisasi posisi jebakan
meriam_image2 = pygame.transform.scale(meriam_image2, (40, 40))  # Sesuaikan ukuran hadiah jika diperlukan
meriam_rect2 = meriam_image2.get_rect()
meriam_rect2.x = (SCREEN_WIDTH // GRID_SIZE - 5) * GRID_SIZE
meriam_rect2.y = (SCREEN_HEIGHT // GRID_SIZE - 5) * GRID_SIZE

# Inisialisasi posisi jebakan
meriam_image3 = pygame.transform.scale(meriam_image3, (40, 40))  # Sesuaikan ukuran hadiah jika diperlukan
meriam_rect3 = meriam_image3.get_rect()
meriam_rect3.x = (SCREEN_WIDTH // GRID_SIZE - 6) * GRID_SIZE
meriam_rect3.y = (SCREEN_HEIGHT // GRID_SIZE - 3) * GRID_SIZE

# Inisialisasi posisi jebakan
meriam_image4 = pygame.transform.scale(meriam_image4, (40, 40))  # Sesuaikan ukuran hadiah jika diperlukan
meriam_rect4 = meriam_image4.get_rect()
meriam_rect4.x = (SCREEN_WIDTH // GRID_SIZE - 2) * GRID_SIZE
meriam_rect4.y = (SCREEN_HEIGHT // GRID_SIZE - 4) * GRID_SIZE

# Inisialisasi posisi jebakan
meriam_image5 = pygame.transform.scale(meriam_image5, (40, 40))  # Sesuaikan ukuran hadiah jika diperlukan
meriam_rect5 = meriam_image5.get_rect()
meriam_rect5.x = (SCREEN_WIDTH // GRID_SIZE - 3) * GRID_SIZE
meriam_rect5.y = (SCREEN_HEIGHT // GRID_SIZE - 1) * GRID_SIZE

# Inisialisasi posisi Coin1
coin_image1 = pygame.transform.scale(coin_image1, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect1 = coin_image1.get_rect()
coin_rect1.x = (SCREEN_WIDTH // GRID_SIZE - 4) * GRID_SIZE
coin_rect1.y = 0

# Inisialisasi posisi Coin2
coin_image2 = pygame.transform.scale(coin_image2, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect2 = coin_image2.get_rect()
coin_rect2.x = (SCREEN_WIDTH // GRID_SIZE - 4) * GRID_SIZE
coin_rect2.y = (SCREEN_HEIGHT // GRID_SIZE - 2) * GRID_SIZE

# Inisialisasi posisi Coin3
coin_image3 = pygame.transform.scale(coin_image3, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect3 = coin_image3.get_rect()
coin_rect3.x = (SCREEN_WIDTH // GRID_SIZE - 1) * GRID_SIZE
coin_rect3.y = (SCREEN_HEIGHT // GRID_SIZE - 5) * GRID_SIZE

# Inisialisasi posisi Coin4
coin_image4 = pygame.transform.scale(coin_image4, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect4 = coin_image4.get_rect()
coin_rect4.x = (SCREEN_WIDTH // GRID_SIZE - 6) * GRID_SIZE
coin_rect4.y = (SCREEN_HEIGHT // GRID_SIZE - 4) * GRID_SIZE

# Inisialisasi posisi Coin5
coin_image5 = pygame.transform.scale(coin_image5, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect5 = coin_image5.get_rect()
coin_rect5.x = (SCREEN_WIDTH // GRID_SIZE - 2) * GRID_SIZE
coin_rect5.y = (SCREEN_HEIGHT // GRID_SIZE - 3) * GRID_SIZE

# Inisialisasi posisi Coin6
coin_image6 = pygame.transform.scale(coin_image6, (45, 45))  # Sesuaikan ukuran hadiah jika diperlukan
coin_rect6 = coin_image6.get_rect()
coin_rect6.x = (SCREEN_WIDTH // GRID_SIZE - 4) * GRID_SIZE
coin_rect6.y = (SCREEN_HEIGHT // GRID_SIZE - 4) * GRID_SIZE

# Inisialisasi pemain di tengah grid
player_rect = player_image.get_rect()
player_rect.center = (GRID_SIZE // 2, GRID_SIZE // 2)
agent2_rect.center = (GRID_SIZE // 2, GRID_SIZE // 2)

# Inisialisasi pemain di tengah grid
player_rect.topleft = (GRID_SIZE // 2, GRID_SIZE // 2)
agent2_rect.topright = (GRID_SIZE // 2, GRID_SIZE // 2)

# inisialisasi score dan steps
score = 0
steps = 0
# Inisialisasi skor untuk agen kedua (Zorotfu)
score_agent2 = 0
steps2 = 0

#coin
initial_coin1_position = (coin_rect1.x, coin_rect1.y)
initial_coin2_position = (coin_rect2.x, coin_rect2.y)
initial_coin3_position = (coin_rect3.x, coin_rect3.y)
initial_coin4_position = (coin_rect4.x, coin_rect4.y)
initial_coin5_position = (coin_rect5.x, coin_rect5.y)
initial_coin6_position = (coin_rect6.x, coin_rect6.y)
#meriam
initial_meriam1_position = (meriam_rect1.x, meriam_rect1.y)
initial_meriam2_position = (meriam_rect2.x, meriam_rect2.y)
initial_meriam3_position = (meriam_rect3.x, meriam_rect3.y)
initial_meriam4_position = (meriam_rect4.x, meriam_rect4.y)
initial_meriam5_position = (meriam_rect5.x, meriam_rect5.y)


# Q-learning parameters
learning_rate = 0.9
discount_factor = 0.99
exploration_prob = 1

# Jumlah total keadaan
num_states = (SCREEN_WIDTH // GRID_SIZE) * (SCREEN_HEIGHT // GRID_SIZE)
num_states2 = (SCREEN_WIDTH // GRID_SIZE) * (SCREEN_HEIGHT // GRID_SIZE)
# Jumlah total tindakan
num_actions = 4  # Kiri, kanan, atas, bawah
num_actions2 = 4  # Kiri, kanan, atas, bawah
# Inisialisasi Q-table
Q = np.zeros((num_states, num_actions))
Q2 = np.zeros((num_states2, num_actions2))

def get_state():
    x, y = player_rect.center
    x = x // GRID_SIZE
    y = y // GRID_SIZE

    # x dan y berada dalam batas yang valid
    x = max(0, min(x, (SCREEN_WIDTH // GRID_SIZE) - 1))
    y = max(0, min(y, (SCREEN_HEIGHT // GRID_SIZE) - 1))

    return y * (SCREEN_WIDTH // GRID_SIZE) + x

# Fungsi untuk mendapatkan keadaan lingkungan agen kedua (Zoro)
def get_state_for_agent2():
    x, y = agent2_rect.center
    x = x // GRID_SIZE
    y = y // GRID_SIZE

    x = max(0, min(x, (SCREEN_WIDTH // GRID_SIZE) - 1))
    y = max(0, min(y, (SCREEN_HEIGHT // GRID_SIZE) - 1))

    return y * (SCREEN_WIDTH // GRID_SIZE) + x

# Fungsi untuk logika agen kedua (Zoro)
def agent2_logic(state_for_agent2):
    return np.random.choice(range(num_actions))

def q_learning_update(state, action, next_state, reward):
    if next_state is not None:  # Pastikan next_state adalah valid
        best_next_action = np.argmax(Q[next_state])
        Q[state][action] = (1 - learning_rate) * Q[state][action] + learning_rate * (reward + discount_factor * Q[next_state][best_next_action])

def q_learning_update2(state_for_agent2, action_agent2, next_state2, reward):
    if next_state2 is not None:  # Pastikan next_state adalah valid
        best_next_action2 = np.argmax(Q2[next_state2])
        Q2[state_for_agent2][action_agent2] = (1 - learning_rate) * Q2[state_for_agent2][action_agent2] + learning_rate * (reward + discount_factor * Q[next_state2][best_next_action2])

num_episodes = 3
episode = 0
for episode in range(num_episodes):
    reset_game = False
    running = True
    game_over = False
    finish = False
    while running:
        state = get_state()
        state_for_agent2 = get_state_for_agent2()
        if random.uniform(0, 1) < exploration_prob:
            action = random.choice(range(num_actions))
        else:
            action = np.argmax(Q[state])

        if random.uniform(0, 1) < exploration_prob:
            action_agent2 = random.choice(range(num_actions2))
        else:
            action_agent2 = np.argmax(Q2[agent2_logic(state_for_agent2)]) 

        prev_state = state
        prev_state2 = state_for_agent2

        # simpan posisi awal pemain
        initial_player_position = player_rect.topleft
        initial_player_position2 = agent2_rect.topright

        # update posisi pemain berdasarkan tindakan yang dipilih.Update player's position based on the selected action
        if action == 0:  # Left
            new_x = player_rect.x - GRID_SIZE
            new_y = player_rect.y
        elif action == 1:  # Right
            new_x = player_rect.x + GRID_SIZE
            new_y = player_rect.y
        elif action == 2:  # Up
            new_x = player_rect.x
            new_y = player_rect.y - GRID_SIZE
        elif action == 3:  # Down
            new_x = player_rect.x
            new_y = player_rect.y + GRID_SIZE
        
        # Pastikan pemain tetap berada di dalam batas layar
        new_x = max(0, min(new_x, SCREEN_WIDTH - player_rect.width))
        new_y = max(0, min(new_y, SCREEN_HEIGHT - player_rect.height))
        new_x = new_x // GRID_SIZE * GRID_SIZE  # Atur posisi x Luffy sesuai dengan grid
        new_y = new_y // GRID_SIZE * GRID_SIZE  # Atur posisi y Luffy sesuai dengan grid

        # Cek apakah pemain mencapai reward setelah pergerakan
        if (new_x, new_y) == (reward_rect.x, reward_rect.y):
            finish = True
            action = np.argmax(Q[state])
            # running = False  # Permainan berakhir ketika pemain mencapai reward
        else:
            player_rect.x = new_x
            player_rect.y = new_y
        
        if (new_x, new_y) == (reward_rect.x, reward_rect.y):
            finish = True
            action_agent2 = np.argmax(Q[agent2_logic(state_for_agent2)]) 
            # running = False  # Permainan berakhir ketika pemain mencapai reward
        else:
            agent2_rect.x = new_x
            agent2_rect.y = new_y
        
        # Update posisi agen kedua (Zoro) berdasarkan tindakan yang dipilih
        if action_agent2 == 0:  # Left
            new_x = agent2_rect.x - GRID_SIZE
            new_y = agent2_rect.y
            # Pastikan agen kedua tetap berada di dalam batas layar
            new_x = max(0, min(new_x, SCREEN_WIDTH - agent2_rect.width))
            new_y = max(0, min(new_y, SCREEN_HEIGHT - agent2_rect.height))
            agent2_rect.x = new_x
            agent2_rect.y = new_y

        elif action_agent2 == 1:  # Right
            new_x = agent2_rect.x + GRID_SIZE
            new_y = agent2_rect.y
            # Pastikan agen kedua tetap berada di dalam batas layar
            new_x = max(0, min(new_x, SCREEN_WIDTH - agent2_rect.width))
            new_y = max(0, min(new_y, SCREEN_HEIGHT - agent2_rect.height))
            agent2_rect.x = new_x
            agent2_rect.y = new_y

        elif action_agent2 == 2:  # Up
            new_x = agent2_rect.x
            new_y = agent2_rect.y - GRID_SIZE
            # Pastikan agen kedua tetap berada di dalam batas layar
            new_x = max(0, min(new_x, SCREEN_WIDTH - agent2_rect.width))
            new_y = max(0, min(new_y, SCREEN_HEIGHT - agent2_rect.height))
            agent2_rect.x = new_x
            agent2_rect.y = new_y

        elif action_agent2 == 3:  # Down
            new_x = agent2_rect.x
            new_y = agent2_rect.y + GRID_SIZE
            # Pastikan agen kedua tetap berada di dalam batas layar
            new_x = max(0, min(new_x, SCREEN_WIDTH - agent2_rect.width))
            new_y = max(0, min(new_y, SCREEN_HEIGHT - agent2_rect.height))
            agent2_rect.x = new_x
            agent2_rect.y = new_y



        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if not game_over:
                    if event.key == pygame.K_LEFT:
                        player_rect.x -= GRID_SIZE
                        steps += 1
                    elif event.key == pygame.K_RIGHT:
                        player_rect.x += GRID_SIZE
                        steps += 1
                    elif event.key == pygame.K_UP:
                        player_rect.y -= GRID_SIZE
                        steps += 1
                    elif event.key == pygame.K_DOWN:
                        player_rect.y += GRID_SIZE
                        steps += 1
                    elif event.key == pygame.K_LEFT:
                        agent2_rect.x -= GRID_SIZE
                        steps2 += 1
                    elif event.key == pygame.K_RIGHT:
                        agent2_rect.x += GRID_SIZE
                        steps2 += 1
                    elif event.key == pygame.K_UP:
                        agent2_rect.y -= GRID_SIZE
                        steps2 += 1
                    elif event.key == pygame.K_DOWN:
                        agent2_rect.y += GRID_SIZE
                        steps2 += 1
                elif game_over and event.key == pygame.K_SPACE:
                    game_over = False
                    reset_game = True

        # Periksa apakah pemain benar-benar telah bergerak.
        if player_rect.topleft != initial_player_position:
            steps += 1
        if agent2_rect.topleft != initial_player_position2:
            steps2 += 1    

        next_state = get_state()
        next_state2 = get_state_for_agent2()
        
        reward = 20
        if finish:
            state = get_state()  # Dapatkan keadaan terakhir
            state_for_agent2 = get_state_for_agent2()
            game_over = True
            reward = 20
            steps = 0  
            score = 0
            score_agent2 = 0
            steps2 = 0
            
            # Reset the player's position
            player_rect.x = 0
            player_rect.y = 0
            agent2_rect.x = 0
            agent2_rect.y = 0
            # Reset the rewards to their initial positions
            coin_rect1.x, coin_rect1.y = initial_coin1_position
            coin_rect2.x, coin_rect2.y = initial_coin2_position
            coin_rect3.x, coin_rect3.y = initial_coin3_position
            coin_rect4.x, coin_rect4.y = initial_coin4_position
            coin_rect5.x, coin_rect5.y = initial_coin5_position
            coin_rect6.x, coin_rect6.y = initial_coin6_position
            # Store the initial positions of meriam at the beginning of your script
            meriam_rect1.x, meriam_rect1.y = initial_meriam1_position
            meriam_rect2.x, meriam_rect2.y = initial_meriam2_position
            meriam_rect3.x, meriam_rect3.y = initial_meriam3_position
            meriam_rect4.x, meriam_rect4.y = initial_meriam4_position
            meriam_rect5.x, meriam_rect5.y = initial_meriam5_position

        q_learning_update(prev_state, action, next_state, reward)
        q_learning_update2(prev_state2, action_agent2, next_state2, reward)

        if player_rect.colliderect(coin_rect1):
            score += 5
            coin_rect1.topleft = (-100, -100)
        if player_rect.colliderect(meriam_rect1):
            score -= 3
            meriam_rect1.topleft = (-100, -100)
        if player_rect.colliderect(coin_rect2):
            score += 5
            coin_rect2.topleft = (-100, -100)
        if player_rect.colliderect(meriam_rect2):
            score -= 3
            meriam_rect2.topleft = (-100, -100)
        if player_rect.colliderect(coin_rect3):
            score += 5
            coin_rect3.topleft = (-100, -100)
        if player_rect.colliderect(meriam_rect3):
            score -= 3
            meriam_rect3.topleft = (-100, -100)
        if player_rect.colliderect(coin_rect4):
            score += 5
            coin_rect4.topleft = (-100, -100)
        if player_rect.colliderect(meriam_rect4):
            score -= 3
            meriam_rect4.topleft = (-100, -100)
        if player_rect.colliderect(coin_rect5):
            score += 5
            coin_rect5.topleft = (-100, -100)
        if player_rect.colliderect(meriam_rect5):
            score -= 3
            meriam_rect5.topleft = (-100, -100)
        if player_rect.colliderect(coin_rect6):
            score += 5
            coin_rect6.topleft = (-100, -100)
        if player_rect.colliderect(reward_rect):
            score += 20
            reward_rect.topleft = (-100, -100)
            
        # Deteksi tabrakan dan mendapatkan hadiah atau terjebak dalam perangkap
        if agent2_rect.colliderect(coin_rect1):
            score_agent2 += 5
            coin_rect1.topleft = (-100, -100)
        if agent2_rect.colliderect(meriam_rect1):
            score_agent2 -= 3
            meriam_rect1.topleft = (-100, -100)
        if agent2_rect.colliderect(coin_rect2):
            score_agent2 += 5 
            coin_rect2.topleft = (-100, -100)  
        if agent2_rect.colliderect(meriam_rect2):
            score_agent2 -= 3 
            meriam_rect2.topleft = (-100, -100)
        if agent2_rect.colliderect(coin_rect3):
            score_agent2 += 5
            coin_rect3.topleft = (-100, -100)
        if agent2_rect.colliderect(meriam_rect3):
            score_agent2 -= 3
            meriam_rect3.topleft = (-100, -100)
        if agent2_rect.colliderect(coin_rect4):
            score_agent2 += 5
            coin_rect4.topleft = (-100, -100)
        if agent2_rect.colliderect(meriam_rect4):
            score_agent2 -= 3
            meriam_rect4.topleft = (-100, -100)
        if agent2_rect.colliderect(coin_rect5):
            score_agent2 += 5 
            coin_rect5.topleft = (-100, -100)  
        if agent2_rect.colliderect(meriam_rect5):
            score_agent2 -= 3 
            meriam_rect5.topleft = (-100, -100)
        if agent2_rect.colliderect(coin_rect6):
            score_agent2 += 5
            coin_rect6.topleft = (-100, -100)
        if agent2_rect.colliderect(reward_rect):
            score_agent2 -= 3
            reward_rect.topleft = (-100, -100)
            finish = True

        screen.fill(GRAY)

        for x in range(0, SCREEN_WIDTH, GRID_SIZE):
            pygame.draw.line(screen, BLACK, (x, 0), (x, SCREEN_HEIGHT))
        for y in range(0, SCREEN_HEIGHT, GRID_SIZE):
            pygame.draw.line(screen, BLACK, (0, y), (SCREEN_WIDTH, y))

        # Gambar reward di posisi saat ini
        screen.blit(reward_image, reward_rect)

        # Gambar meriam di posisi saat ini
        screen.blit(meriam_image1, meriam_rect1)

        # Gambar meriam di posisi saat ini
        screen.blit(meriam_image2, meriam_rect2)

        # Gambar meriam di posisi saat ini
        screen.blit(meriam_image3, meriam_rect3)

        # Gambar meriam di posisi saat ini
        screen.blit(meriam_image4, meriam_rect4)

        # Gambar meriam di posisi saat ini
        screen.blit(meriam_image5, meriam_rect5)

        # Gambar coin1 di posisi saat ini
        screen.blit(coin_image1, coin_rect1)

        # Gambar coin2 di posisi saat ini
        screen.blit(coin_image2, coin_rect2)

        # Gambar coin3 di posisi saat ini
        screen.blit(coin_image3, coin_rect3)

        # Gambar coin4 di posisi saat ini
        screen.blit(coin_image4, coin_rect4)

        # Gambar coin5 di posisi saat ini
        screen.blit(coin_image5, coin_rect5)

        # Gambar coin5 di posisi saat ini
        screen.blit(coin_image6, coin_rect6)

        # Gambar pemain di posisi saat ini
        screen.blit(player_image, player_rect)
        screen.blit(agent2_image, agent2_rect)
        
        player_rect.topleft = (player_rect.x + player_rect.width // 2, player_rect.y + player_rect.height // 2)
        agent2_rect.center = (agent2_rect.x + agent2_rect.width // 2, agent2_rect.y + agent2_rect.height // 2)

        # text = font.render(f"Score: {score}", True, (255, 0, 0))
        # screen.blit(text, (5, 5))
        state = get_state()
        state_for_agent2 = get_state_for_agent2()
        action = np.argmax(Q[state])
        action_agent2 = np.argmax(Q2[agent2_logic(state_for_agent2)]) 
        pygame.display.flip()
        

        # Perbarui tampilan

        # state = get_state()
        # Q = np.load('q_table2.npy')
        # action = np.argmax(Q[state])
        pygame.time.delay(200)
    episode+=1
    print(episode, Q, Q2)
    np.save('q_table_explored10.npy', Q)
pygame.quit()
print(f"Jumlah langkah: {steps + steps2}")
print(f"Score: {score + score_agent2}")

